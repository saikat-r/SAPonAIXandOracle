alter system set db_recovery_file_dest='/ora_fra' scope=memory; 

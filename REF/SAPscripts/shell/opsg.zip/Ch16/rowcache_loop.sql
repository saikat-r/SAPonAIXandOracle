exec cycle(&1);

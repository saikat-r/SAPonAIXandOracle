sqlplus %1 @spin_count
start sqlplus %1 @query_loops 120 100 true false false true
start sqlplus %1 @query_loops 120 100 true false false true
start sqlplus %1 @query_loops 120 100 true false false true
start sqlplus %1 @query_loops 120 100 true false false true
start sqlplus %1 @query_loops 120 100 true false false true
start sqlplus %1 @query_loops 120 100 true false false true
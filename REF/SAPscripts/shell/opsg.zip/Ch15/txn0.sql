create table customers as select * from sh.customers; 
create table sales as select * from sh.sales; 

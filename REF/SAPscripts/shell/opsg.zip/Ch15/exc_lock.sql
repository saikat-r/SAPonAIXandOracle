lock table customers in exclusive mode; 

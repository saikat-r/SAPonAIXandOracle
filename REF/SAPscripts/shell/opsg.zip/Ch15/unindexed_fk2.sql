UPDATE employees
SET salary = salary * 1.1
WHERE employee_id = 198;

SELECT * FROM v_my_locks;

start sqlplus %1 @lock_two_rows 1 2
start sqlplus %1 @lock_two_rows 2 3
start sqlplus %1 @lock_two_rows 3 2
start sqlplus %1 @lock_two_rows 1 4
start sqlplus %1 @lock_two_rows 3 6
start sqlplus %1 @lock_two_rows 6 1
start sqlplus %1 @lock_two_rows 3 3

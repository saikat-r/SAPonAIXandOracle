update sales set channel_id=0 where channel_id=&1; 

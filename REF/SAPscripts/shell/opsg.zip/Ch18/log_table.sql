create table log_table (id number, log_data varchar(2000)); 
create sequence log_table_seq; 

select * from log_table order by id desc 

#include <Python.h>
#include <string.h>
#include <signal.h>

#include <saprfc.h>
#include <sapitab.h>

#define MAX_PARA 64

#define RFCIMPORT     0
#define RFCEXPORT     1
#define RFCTABLE      2


#define BUF_SIZE 8192

#define RFC_WAIT_TIME 10

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

  
/* SAP flag for Windows NT or 95 */
#ifdef _WIN32
#  ifndef SAPonNT
#    define SAPonNT
#  endif
#endif

#include "saprfc.h"
#include "sapitab.h"

#if defined(SAPonNT)
#include "windows.h"
#endif

/* name of installed function for global callback in tRFC */
char name_user_global_server[31] = "%%USER_GLOBAL_SERVER";

// fake up a definition of bool if it doesnt exist
#ifndef bool
typedef unsigned char    bool;
#endif

// create my true and false
#ifndef false
typedef enum { false, true } mybool;
#endif

/* global pointers to saprfc object */
PyObject *global_saprfc;

/* global reference to main loop callback for registered RFC */
PyObject *py_callback;

/* the current RFC_TID  */
RFC_TID current_tid;


/*
 * local prototypes & declarations
 */

static RFC_RC DLL_CALL_BACK_FUNCTION handle_request( RFC_HANDLE handle, PyObject *py_iface );
static RFC_RC DLL_CALL_BACK_FUNCTION do_docu( RFC_HANDLE handle );
RFC_RC loop_callback(PyObject *py_callback_handler);
void get_attributes(RFC_HANDLE rfc_handle, PyObject *py_sysinfo);
static int  DLL_CALL_BACK_FUNCTION  TID_check(RFC_TID tid);
static void DLL_CALL_BACK_FUNCTION  TID_commit(RFC_TID tid);
static void DLL_CALL_BACK_FUNCTION  TID_confirm(RFC_TID tid);
static void DLL_CALL_BACK_FUNCTION  TID_rollback(RFC_TID tid);
static RFC_RC DLL_CALL_BACK_FUNCTION user_global_server(RFC_HANDLE rfc_handle);
static char *user_global_server_docu(void);
static RFC_RC install_docu    ( RFC_HANDLE handle );
static char * do_docu_docu( void );


/* store a reference to the documentation array ref */
PyObject *py_store_docu;


static void * MyValue( int type, char * value, int len, bool copy );

void initsaprfcutil(void);
void stop_execution (int sig);

void
stop_execution (int sig){
  fprintf(stderr, "CTL-C pressed - exiting...\n"); 
  exit(1);
}


/* standard error call back handler - installed into connnection object */
static void  DLL_CALL_BACK_FUNCTION  rfc_error( char * operation ){
  RFC_ERROR_INFO_EX  error_info;
  
  fprintf( stderr, "RFC Call/Exception: %s\n", operation );
  RfcLastErrorEx(&error_info);
  fprintf( stderr, "\nGroup       Error group %d", error_info.group );
  fprintf( stderr, "\nKey         %s", error_info.key );
  fprintf( stderr, "\nMessage     %s\n", error_info.message );
  fprintf(stderr, "RFC Call/Exception: %s \tError group: %d \tKey: %s \tMessage: %s",
      operation,
      error_info.group, 
      error_info.key,
      error_info.message );
  exit(1);

}

/* copy the value of a parameter to a new pointer variable to be passed back onto the 
   parameter pointer argument */
static void * MyValue( int type, char * value, int len, bool copy ){
    char * ptr;

    ptr = malloc( len + 1 );
    if ( ptr == NULL )
	return 0;
    memset(ptr, 0, len + 1);
    switch ( type ){
      default:
        if ( copy == true ){
          memcpy(ptr, value, len );
	};
        break;
    };
    return ptr;
}

/* create a parameter space and zero it */
static void * make_space( int len ){
    char * ptr;

    ptr = malloc( len + 1 );
    if ( ptr == NULL )
        return 0;
    memset(ptr, 0, len + 1);
    return ptr;
}



/* build a connection to an SAP system */
static PyObject* saprfcutil_connect(PyObject *self, PyObject *args){

    RFC_ENV            new_env;
    RFC_HANDLE         handle;
    RFC_ERROR_INFO_EX  error_info;
    char connectstring[2048];
    char errstr[1024];
    PyObject *inst, *constr;

    if (! PyArg_Parse(args, "(O)", &inst)) {
			  Py_DECREF(args);
        return NULL;
		}
    else {
        if (!(constr = PyObject_GetAttrString(inst, "constr")))
				   return NULL;
        sprintf(connectstring, "%s", PyString_AsString(constr));
        new_env.allocate = NULL;
        new_env.errorhandler = rfc_error;
        RfcEnvironment( &new_env );
				/* fprintf(stderr, "Connection String: %s\n", connectstring); */
        handle = RfcOpenEx(connectstring, &error_info);
			  Py_DECREF(args);
			  Py_DECREF(constr);
        if (handle == RFC_HANDLE_NULL){
    	    RfcLastErrorEx(&error_info);
	        fprintf(stderr, "GROUP \t %d \t KEY \t %s \t MESSAGE \t %s \n",
                 error_info.group, error_info.key, error_info.message );
          sprintf(errstr, "RFC Call/Exception: Connection Failed \tError group: %d \tKey: %s \tMessage: %s",
                error_info.group, 
                error_info.key,
                error_info.message );
          PyErr_Format(PyExc_TypeError, "%s", errstr);
          return NULL;
        };
        return Py_BuildValue( "i", ( int ) handle);
    }
    
}


/* Disconnect from an SAP system */
static PyObject* saprfcutil_close(PyObject *self, PyObject *args){

    RFC_HANDLE handle;
    int connection;

    if (! PyArg_Parse(args, "(i)", &connection)) {
				Py_DECREF(args);
        return NULL;
		}
    else {
      handle = connection;
      RfcClose( handle ); 
			Py_DECREF(args);
      return Py_BuildValue( "i", 1);
    }

}


/* Get logon ticket */
static PyObject* saprfcutil_get_ticket(PyObject *self, PyObject *args){

    RFC_HANDLE handle;
    RFC_CHAR ticket[1024];
    RFC_RC res;
    int connection;

    if (! PyArg_Parse(args, "(i)", &connection)) {
			  Py_DECREF(args);
        return NULL;
		}
    else {
      handle = connection;
      res = RfcGetTicket( handle, ticket ); 
			Py_DECREF(args);
      if (RFC_OK == res) {
         PyObject *ret = Py_BuildValue( "s", ticket);
         return ret;
      }

      return NULL;
    }

}


/* build the RFC call interface, do the RFC call, and then build a complex
  hash structure of the results to pass back into python */
static PyObject* saprfcutil_call_receive(PyObject *self, PyObject *args){


   RFC_PARAMETER      myexports[MAX_PARA];
   RFC_PARAMETER      myimports[MAX_PARA];
   RFC_TABLE          mytables[MAX_PARA];
   RFC_RC             rc;
   RFC_HANDLE         handle;
   char *             exception, errstr[1024];
   RFC_ERROR_INFO_EX  error_info;

   int                tab_cnt, 
                      imp_cnt,
                      exp_cnt,
                      irow,
                      a_index,
                      tab_index,
                      i,
                      j;

   PyObject  *inst, *iface, *function, *connection, *parms, *parmsidx, *tabarray, *aentry, *tabentry;
   PyObject  *parmname, *parmtype, *parmlen, *parmintype, *value;

   if (! PyArg_Parse(args, "(OO)", &inst, &iface)) {
			  Py_DECREF(args);
        return NULL;
	 }
	 Py_DECREF(args);

   if (!(function = PyObject_GetAttrString(iface, "name")))
        return NULL;
   if (!(connection = PyObject_GetAttrString(inst, "connection")))
        return NULL;
   handle = (int) PyInt_AsLong( connection );
   if (!(parms = PyObject_GetAttrString(iface, "parms")))
        return NULL;
   if (!(parmsidx = PyObject_GetAttrString(iface, "parmsindex")))
        return NULL;
   if (!PyList_Check(parms)){
       fprintf(stderr, "not a list object\n");
       exit(1);
   }
   if (!PyDict_Check(parmsidx)){
       fprintf(stderr, "not a dictionary object\n");
       exit(1);
   }
   a_index = PyList_Size(parms);

   tab_cnt = 0;
   exp_cnt = 0;
   imp_cnt = 0;

   /* get the RFC interface definition array and iterate   */
   for (i = 0; i < a_index; i++) {
     /* grab each parameter hash */
     aentry = PyList_GetItem(parms,i);
     parmname = PyObject_GetAttrString(aentry, "name");
     parmtype = PyObject_GetAttrString(aentry, "type");
     parmintype = PyObject_GetAttrString(aentry, "intype");
     parmlen = PyObject_GetAttrString(aentry, "len");

       /* determine the interface parameter type and build a definition */
     switch ( (int) PyInt_AsLong(parmtype) ){
	   case RFCIMPORT:
	     /* build an import parameter and allocate space for it to be returned into */
	     myimports[imp_cnt].name = malloc( strlen(PyString_AsString(parmname)) + 1);
	     if ( myimports[imp_cnt].name == NULL )
                 return Py_BuildValue( "i", 0);
	     memset(myimports[imp_cnt].name, 0, strlen(PyString_AsString(parmname)) + 1);
	     memcpy(myimports[imp_cnt].name, PyString_AsString(parmname), strlen(PyString_AsString(parmname)));
	     myimports[imp_cnt].nlen = strlen(PyString_AsString(parmname));
	     myimports[imp_cnt].addr = MyValue(  (int) PyInt_AsLong(parmintype),
  					       "",
					       (int) PyInt_AsLong(parmlen), false );
	     myimports[imp_cnt].leng = (int) PyInt_AsLong(parmlen);
	     myimports[imp_cnt].type = (int) PyInt_AsLong(parmintype);
       //value = PyObject_GetAttrString(aentry, "value");
	     ++imp_cnt;
	     break;

	   case RFCEXPORT:
	     /* build an export parameter and pass the value onto the structure */
	     myexports[exp_cnt].name = malloc( strlen(PyString_AsString(parmname)) + 1);
	     if ( myexports[exp_cnt].name == NULL )
                 return Py_BuildValue( "i", 0);
	     memset(myexports[exp_cnt].name, 0, strlen(PyString_AsString(parmname)) + 1);
	     memcpy(myexports[exp_cnt].name, PyString_AsString(parmname), strlen(PyString_AsString(parmname)));
	     myexports[exp_cnt].nlen = strlen(PyString_AsString(parmname));
       value = PyObject_GetAttrString(aentry, "value");
	     if (! PyObject_IsTrue(value))
	         break;
       myexports[exp_cnt].addr = MyValue(  (int) PyInt_AsLong(parmintype),
 	       			       PyString_AsString(value),
	         		       (int) PyInt_AsLong(parmlen), true );

	     myexports[exp_cnt].leng = (int) PyInt_AsLong(parmlen);
	     myexports[exp_cnt].type = (int) PyInt_AsLong(parmintype);
       Py_DECREF(value);
	     ++exp_cnt;
	     break;

	   case RFCTABLE:
	     /* construct a table parameter and copy the table rows on to the table handle */
	     mytables[tab_cnt].name = malloc( strlen(PyString_AsString(parmname)) + 1);
	     if ( mytables[tab_cnt].name == NULL )
                 return Py_BuildValue( "i", 0);
	     memset(mytables[tab_cnt].name, 0, strlen(PyString_AsString(parmname)) + 1);
	     memcpy(mytables[tab_cnt].name, PyString_AsString(parmname), strlen(PyString_AsString(parmname)));
	     mytables[tab_cnt].nlen = strlen(PyString_AsString(parmname));
	     mytables[tab_cnt].leng = (int) PyInt_AsLong(parmlen);
       mytables[tab_cnt].itmode = RFC_ITMODE_BYREFERENCE;
       mytables[tab_cnt].type = RFCTYPE_CHAR; 
       mytables[tab_cnt].ithandle = 
	         ItCreate( mytables[tab_cnt].name, (int) PyInt_AsLong(parmlen), 0 , 0 );
	     if ( mytables[tab_cnt].ithandle == NULL )
                 return Py_BuildValue( "i", 0);

       value = PyObject_GetAttrString(aentry, "value");
	     if (PyObject_IsTrue(value) && PyList_Check(value)){
           tab_index = PyList_Size(value);
	         for (j = 0; j < tab_index; j++) {
             tabentry = PyList_GetItem(value,j);
	           memcpy(ItAppLine(mytables[tab_cnt].ithandle),
	                  PyString_AsString(tabentry),
		                mytables[tab_cnt].leng);
	         };
	     }
       Py_DECREF(value);
	     tab_cnt++;

	     break;
	 default:
	     fprintf(stderr, "    I DONT KNOW WHAT THIS PARAMETER IS: %s \n", PyString_AsString(PyObject_GetAttrString(aentry, "name")));
             exit(1);
	     break;
       };

     Py_DECREF(parmname);
     Py_DECREF(parmtype);
     Py_DECREF(parmintype);
     Py_DECREF(parmlen);

   };

   /* tack on a NULL value parameter to each type to signify that there are no more */
   myexports[exp_cnt].name = NULL;
   myexports[exp_cnt].nlen = 0;
   myexports[exp_cnt].leng = 0;
   myexports[exp_cnt].addr = NULL;
   myexports[exp_cnt].type = 0;

   myimports[imp_cnt].name = NULL;
   myimports[imp_cnt].nlen = 0;
   myimports[imp_cnt].leng = 0;
   myimports[imp_cnt].addr = NULL;
   myimports[imp_cnt].type = 0;

   mytables[tab_cnt].name = NULL;
   mytables[tab_cnt].ithandle = NULL;
   mytables[tab_cnt].nlen = 0;
   mytables[tab_cnt].leng = 0;
   mytables[tab_cnt].type = 0;

   /* do the actual RFC call to SAP */
   rc =  RfcCallReceive( handle, PyString_AsString(function),
				    myexports,
				    myimports,
				    mytables,
				    &exception );

	 Py_DECREF(function);
   Py_DECREF(connection);
   Py_DECREF(parms);

   /* check the return code - if necessary construct an error message */
   if ( rc != RFC_OK ){
       RfcLastErrorEx( &error_info );
     if (( rc == RFC_EXCEPTION ) ||
         ( rc == RFC_SYS_EXCEPTION )) {
	  sprintf(errstr, "EXCEPT\t%s\tGROUP\t%d\tKEY\t%s\tMESSAGE\t%s", exception, error_info.group, error_info.key, error_info.message );
     } else {
	  sprintf(errstr, "EXCEPT\t%s\tGROUP\t%d\tKEY\t%s\tMESSAGE\t%s","RfcCallReceive", error_info.group, error_info.key, error_info.message);
     };
      PyErr_Format(PyExc_TypeError, "%s", errstr);
      return NULL;
   };

   /* free up the used memory for export parameters */
   for (exp_cnt = 0; exp_cnt < MAX_PARA; exp_cnt++){
       if ( myexports[exp_cnt].name == NULL ){
	       break;
       } else {
	       free(myexports[exp_cnt].name);
       };
       myexports[exp_cnt].name = NULL;
       myexports[exp_cnt].nlen = 0;
       myexports[exp_cnt].leng = 0;
       myexports[exp_cnt].type = 0;
       if ( myexports[exp_cnt].addr != NULL ){
	       free(myexports[exp_cnt].addr);
       };
       myexports[exp_cnt].addr = NULL;
   };

   /* retrieve the values of the import parameters and free up the memory */
   for (imp_cnt = 0; imp_cnt < MAX_PARA; imp_cnt++){
       if ( myimports[imp_cnt].name == NULL ){
	       break;
       };
       aentry = PyDict_GetItemString(parmsidx, myimports[imp_cnt].name);
       switch ( myimports[imp_cnt].type ){
	       default:
           value = PyString_FromStringAndSize(myimports[imp_cnt].addr, myimports[imp_cnt].leng);
           PyObject_SetAttrString(aentry, "value", value);
					 Py_DECREF(value);
	         break;
       };

       free(myimports[imp_cnt].name);
       myimports[imp_cnt].name = NULL;
       myimports[imp_cnt].nlen = 0;
       myimports[imp_cnt].leng = 0;
       myimports[imp_cnt].type = 0;
       if ( myimports[imp_cnt].addr != NULL ){
	       free(myimports[imp_cnt].addr);
       };
       myimports[imp_cnt].addr = NULL;
   };
   
   /* retrieve the values of the table parameters and free up the memory */
   for (tab_cnt = 0; tab_cnt < MAX_PARA; tab_cnt++){
       if ( mytables[tab_cnt].name == NULL ){
    	   break;
       };
       aentry = PyDict_GetItemString(parmsidx, mytables[tab_cnt].name);
       tabarray = PyList_New(ItFill(mytables[tab_cnt].ithandle));
       /*  grab each table row and push onto an array */
       for (irow = 1; irow <=  ItFill(mytables[tab_cnt].ithandle); irow++){
           PyList_SetItem( tabarray, irow - 1, 
                        PyString_FromStringAndSize( ItGetLine( mytables[tab_cnt].ithandle, irow ), 
	    	                    mytables[tab_cnt].leng ) );
       };
       PyObject_SetAttrString(aentry, "value", tabarray);
			 Py_DECREF(tabarray);
	   
       free(mytables[tab_cnt].name);
       mytables[tab_cnt].name = NULL;
       if ( mytables[tab_cnt].ithandle != NULL ){
	       ItFree( mytables[tab_cnt].ithandle );
       };
       mytables[tab_cnt].ithandle = NULL;
       mytables[tab_cnt].nlen = 0;
       mytables[tab_cnt].leng = 0;
       mytables[tab_cnt].type = 0;

   };

   Py_DECREF(parmsidx);

   if ( rc == RFC_OK ){
     return Py_BuildValue( "i", 1);
   } else {
     return Py_BuildValue( "i", 0);
   }
}




RFC_RC loop_callback(PyObject *py_callback_handler)
{

    int result;
    PyObject *py_rvalue;

    /* if there is no handler then get out of here */
    if (py_callback_handler == Py_None)
      return RFC_OK;

    py_rvalue = PyObject_CallMethod(py_callback_handler, "LoopHandler", "(O)", global_saprfc);
    
    if (py_rvalue == NULL){
       PyErr_Format(PyExc_TypeError, "Loop Callback Error - no return value (1)");
       return RFC_SYS_EXCEPTION;
    }

    result = PyInt_AsLong(py_rvalue);
    Py_DECREF(py_rvalue);
    if (result >= 0){
      return RFC_OK;
    } else {
      return RFC_SYS_EXCEPTION;
    }

}



/*--------------------------------------------------------------------*/
/* TID_CHECK-Function for transactional RFC                           */
/*--------------------------------------------------------------------*/
static int DLL_CALL_BACK_FUNCTION TID_check(RFC_TID tid)
{
    PyObject *py_callback, *py_rvalue;

    if (!(py_callback = PyObject_GetAttrString(global_saprfc, "trfc")))
      return 0;
    //return RFC_SYS_EXCEPTION;

    py_rvalue = PyObject_CallMethod(py_callback, "TRFCCheck", "(OS)", global_saprfc, PyString_FromString(tid));
    Py_DECREF(py_callback);
    
    if (py_rvalue == NULL){
       PyErr_Format(PyExc_TypeError, "TRFCCheck Callback Error - no return value (2)");
       return RFC_SYS_EXCEPTION;
    }

    if (PyObject_IsTrue(py_rvalue)){
      memset(current_tid, 0, sizeof(current_tid));
      return 1;
    } else {
      sprintf(current_tid+0, "%s", tid);
      return 0;
    }

}


/*--------------------------------------------------------------------*/
/* TID_COMMIT-Function for transactional RFC                          */
/*--------------------------------------------------------------------*/
static void DLL_CALL_BACK_FUNCTION TID_commit(RFC_TID tid)
{
    PyObject *py_callback, *py_rvalue;

    if (!(py_callback = PyObject_GetAttrString(global_saprfc, "trfc")))
      return;

    py_rvalue = PyObject_CallMethod(py_callback, "TRFCCommit", "(OS)", global_saprfc, PyString_FromString(tid));
    Py_DECREF(py_callback);
    
    return;
}


/*--------------------------------------------------------------------*/
/* CONFIRM-Function for transactional RFC                             */
/*--------------------------------------------------------------------*/
static void DLL_CALL_BACK_FUNCTION TID_confirm(RFC_TID tid)
{
    PyObject *py_callback, *py_rvalue;

    if (!(py_callback = PyObject_GetAttrString(global_saprfc, "trfc")))
      return;

    py_rvalue = PyObject_CallMethod(py_callback, "TRFCConfirm", "(OS)", global_saprfc, PyString_FromString(tid));
    Py_DECREF(py_callback);
    
    return;
}


/*--------------------------------------------------------------------*/
/* TID_ROLLBACK-Function for transactional RFC                        */
/*--------------------------------------------------------------------*/
static void DLL_CALL_BACK_FUNCTION TID_rollback(RFC_TID tid)
{
    PyObject *py_callback, *py_rvalue;

    if (!(py_callback = PyObject_GetAttrString(global_saprfc, "trfc")))
      return;

    py_rvalue = PyObject_CallMethod(py_callback, "TRFCRollback", "(OS)", global_saprfc, PyString_FromString(tid));
    Py_DECREF(py_callback);
    
    return;
}


static RFC_RC DLL_CALL_BACK_FUNCTION user_global_server(RFC_HANDLE handle)
{

  RFC_RC rc;
  RFC_FUNCTIONNAME  funcname;
  PyObject *py_ifaces, *aentry, *py_callback;

  rc = RfcGetName(handle, funcname);
  if (rc != RFC_OK)
  {
       fprintf(stderr, "RFC connection failure code: %d \n", rc);
       PyErr_Format(PyExc_TypeError, "RFC connection failure code: %d", rc);
       RfcClose( handle );
       return rc;
  }

  /* check at this point for registered functions */
  if (!(py_ifaces = PyObject_GetAttrString(global_saprfc, "ifacesindex")))
    return RFC_SYS_EXCEPTION;
  aentry = PyDict_GetItemString(py_ifaces, funcname);
  Py_DECREF(py_ifaces);
  if (aentry == NULL){
    fprintf(stderr, "the MISSING Function Name is: %s\n", funcname);
    RfcRaise( handle, "FUNCTION_MISSING" );
    return RFC_NOT_FOUND;
  }
  Py_INCREF(aentry);

  rc = handle_request(handle, aentry);

  Py_DECREF(aentry);

  if (!(py_callback = PyObject_GetAttrString(aentry, "callback")))
    return RFC_SYS_EXCEPTION;
  Py_DECREF(py_callback);
  //Py_XINCREF(py_callback);
  rc = loop_callback(py_callback);

  return rc;
}

#undef  NL
#define NL "\n"

static char *user_global_server_docu(void)
{
  static char docu[] =
  "The RFC library will call this function if any unknown"            NL
  "RFC function should be executed in this RFC server program."       NL
    ;
  return docu;
}



static PyObject* saprfcutil_accept(PyObject *self, PyObject *args){

   static RFC_ENV    env;
   RFC_ERROR_INFO_EX  error_info;
   RFC_HANDLE handle;
   RFC_RC     rc;
   RFC_FUNCTIONNAME funcname;
   RFC_INT wtime = 0; 
   RFC_INT ntotal,
           ninit,
           nready,
           nbusy;
   char   gwserv[8];
   char   gwhost[128];
   char   tpname[128];
   char errstr[1024];
   PyObject *inst, *py_gwserv, *py_gwhost, *py_tpname, *py_connstr, *py_wait, *py_ifaces, *aentry, *py_trfc;

   if (! PyArg_Parse(args, "(O)", &inst))
        return NULL;
   else {
        if (!(py_gwhost = PyObject_GetAttrString(inst, "gwhost")))
	   return NULL;
        if (!(py_gwserv = PyObject_GetAttrString(inst, "gwserv")))
	   return NULL;
        if (!(py_tpname = PyObject_GetAttrString(inst, "tpname")))
	   return NULL;
        if (!(py_connstr = PyObject_GetAttrString(inst, "connstr")))
	   return NULL;
        if (!(py_wait = PyObject_GetAttrString(inst, "wait")))
	   return NULL;
        if (!(py_callback = PyObject_GetAttrString(inst, "callback")))
	   return NULL;
        if (!(py_store_docu = PyObject_GetAttrString(inst, "docu")))
	   return NULL;
        if (!(py_ifaces = PyObject_GetAttrString(inst, "ifacesindex")))
	   return NULL;
        if (!(py_trfc = PyObject_GetAttrString(inst, "trfc")))
	   return NULL;
   }
   Py_XINCREF(py_callback);

   sprintf(gwserv, "%s", PyString_AsString(py_gwserv) ); 
   sprintf(gwhost, "%s", PyString_AsString(py_gwhost) ); 
   sprintf(tpname, "%s", PyString_AsString(py_tpname) ); 
   wtime = PyInt_AsLong(py_wait);
   if (wtime == 0)
      wtime = RFC_WAIT_TIME;

   Py_DECREF(args);
   Py_DECREF(py_gwserv);
   Py_DECREF(py_gwhost);
   Py_DECREF(py_tpname);
   Py_DECREF(py_connstr);
   Py_DECREF(py_wait);
   Py_DECREF(py_ifaces);

   memset(current_tid, 0, sizeof(current_tid));

   global_saprfc = inst;
   Py_INCREF(global_saprfc);

   env.errorhandler = rfc_error;
   RfcEnvironment( &env );

   /*
    * accept connection
    *
    * (command line argv must be passed to RfcAccept)
    */
   handle = RfcAcceptExt( PyString_AsString(py_connstr) );
   rc = RfcCheckRegisterServer( tpname,
                                gwhost,
 			        gwserv, 
 			        &ntotal, &ninit, &nready, &nbusy, &error_info);

   if (rc != RFC_OK)
   {
      fprintf(stderr, "GROUP \t %d \t KEY \t %s \t MESSAGE \t %s \n",
                 error_info.group, error_info.key, error_info.message );
      sprintf(errstr, "RFC Call/Exception: Connection Failed \tError group: %d \tKey: %s \tMessage: %s",
                error_info.group, 
                error_info.key,
                error_info.message );
      PyErr_Format(PyExc_TypeError, "%s", errstr);
      return NULL;
   }

   /* obscure error when SAP is starting up but still get RFC_OK above */
   if (ntotal == 0)
   {
      PyErr_Format(PyExc_TypeError, "Group       Error group 102\nKey         RFC_ERROR_COMMUNICATION\nMessage     Error connecting to the gateway - no registered servers found\n\n");
      return NULL;
   }

   if (PyObject_IsTrue(py_trfc)){
   /* Install transaction control   */
     RfcInstallTransactionControl((RFC_ON_CHECK_TID)   TID_check,
                                  (RFC_ON_COMMIT)      TID_commit,
                                  (RFC_ON_ROLLBACK)    TID_rollback,
                                  (RFC_ON_CONFIRM_TID) TID_confirm);
   }

   rc = install_docu(handle);

   if( rc != RFC_OK )
   {
      RfcAbort( handle, "Initialisation error" );
      PyErr_Format(PyExc_TypeError, "Initialisation error in the gateway");
      return NULL;
   }

    /* global handler for tRFC  */
   if (PyObject_IsTrue(py_trfc)){
        rc = RfcInstallFunction(name_user_global_server,
                             (RFC_ONCALL) user_global_server,
	                      user_global_server_docu());
       if( rc != RFC_OK )
       {
           fprintf(stderr, "\nERROR: Install %s     rfc_rc = %d",
	                   name_user_global_server, rc);
           RfcAbort( handle, "Cant install global tRFC handler" );
           PyErr_Format(PyExc_TypeError, "Cant install global tRFC handler");
           return NULL;
       }
   }

   
    signal (SIGINT, stop_execution);
   /*
    * enter main loop
    */
   do
   {
     rc = RfcWaitForRequest(handle, wtime);

     /* needs to get an RFC_OK or RFC_RETRY */
     if (rc == RFC_RETRY){
       /*  do event loop callback here for interloop breakout */
       rc = loop_callback(py_callback);
       continue;
     }

     /* short circuit here for tRFC  */
     if (PyObject_IsTrue(py_trfc)){
         rc = RfcDispatch(handle);
         continue;
     }

     /* this will block until a straight RFC call is made */
     if (rc == RFC_OK)
       rc = RfcGetName(handle, funcname);

     if (rc != RFC_OK){
       PyErr_Format(PyExc_TypeError, "RFC connection failure code: %d", rc);
       RfcClose( handle );
       return NULL;
     }

     /* check at this point for registered functions */
     aentry = PyDict_GetItemString(py_ifaces, funcname);
     if (aentry == NULL){
       fprintf(stderr, "the MISSING Function Name is: %s\n", funcname);
       RfcRaise( handle, "FUNCTION_MISSING" );
       /* do event callback to intertwine other events */
       rc = loop_callback(py_callback);
       continue;
     }
     Py_INCREF(aentry);

     /* pass in the interface to be handled */
     rc = handle_request(handle, aentry);
     if (rc != RFC_OK)
       continue;

     /* do event callback to intertwine other events */
     rc = loop_callback(py_callback);

   } while( rc == RFC_OK || rc == RFC_RETRY );

   Py_DECREF(py_trfc);
   Py_DECREF(py_callback);
   Py_DECREF(py_store_docu);

   /*
    * connection was closed by the client :
    * also close connection and terminate
    */
   RfcClose( handle );
   return Py_BuildValue( "i", rc);
} /* main */



static RFC_RC install_docu( RFC_HANDLE handle )
{
   RFC_RC rc;

   /*
    * install the function modules offered
    *
    * the documentation texts are placed in static memory
    * within some static functions to keep things readable.
    */

   /*
    * RFC_DOCU interface
    */
   rc = RfcInstallFunction("RFC_DOCU",
			    do_docu,
			    do_docu_docu() );
   if( rc != RFC_OK ) return rc;

   return RFC_OK;
} /* install_docu */



/*====================================================================*/
/*                                                                    */
/* Get specific info about an RFC connection                          */
/*                                                                    */
/*====================================================================*/
void get_attributes(RFC_HANDLE rfc_handle, PyObject *py_sysinfo)
{
  RFC_ATTRIBUTES    rfc_attributes;
  RFC_RC rc;
	PyObject *value;

  PyDict_Clear(py_sysinfo);

  rc = RfcGetAttributes(rfc_handle, &rfc_attributes);
  if (rc != RFC_OK)
    return;

  //PyDict_SetItemString(py_sysinfo, "dest", PyString_FromStringAndSize(rfc_attributes.dest, strlen(rfc_attributes.dest)));
	value = PyString_FromStringAndSize(rfc_attributes.dest, strlen(rfc_attributes.dest));
  PyDict_SetItemString(py_sysinfo, "dest", value);
	//Py_DECREF(value);
  //PyDict_SetItemString(py_sysinfo, "localhost", PyString_FromStringAndSize(rfc_attributes.own_host, strlen(rfc_attributes.own_host)));
	value = PyString_FromStringAndSize(rfc_attributes.own_host, strlen(rfc_attributes.own_host));
  PyDict_SetItemString(py_sysinfo, "localhost", value);
	//Py_DECREF(value);
  if (rfc_attributes.rfc_role == RFC_ROLE_CLIENT)
  {
    if (rfc_attributes.partner_type == RFC_SERVER_EXT) {
      //PyDict_SetItemString(py_sysinfo, "servprogname", PyString_FromStringAndSize(rfc_attributes.partner_host, strlen(rfc_attributes.partner_host)));
		  value = PyString_FromStringAndSize(rfc_attributes.partner_host, strlen(rfc_attributes.partner_host));
      PyDict_SetItemString(py_sysinfo, "servprogname", value);
	    //Py_DECREF(value);
		}
    else if (rfc_attributes.partner_type == RFC_SERVER_EXT_REG) {
      //PyDict_SetItemString(py_sysinfo, "servprogid", PyString_FromStringAndSize(rfc_attributes.partner_host, strlen(rfc_attributes.partner_host)));
		  value = PyString_FromStringAndSize(rfc_attributes.partner_host, strlen(rfc_attributes.partner_host));
      PyDict_SetItemString(py_sysinfo, "servprogid", value);
	    //Py_DECREF(value);
		}
    else {
      //PyDict_SetItemString(py_sysinfo, "partnerhost", PyString_FromStringAndSize(rfc_attributes.partner_host, strlen(rfc_attributes.partner_host)));
			value = PyString_FromStringAndSize(rfc_attributes.partner_host, strlen(rfc_attributes.partner_host));
      PyDict_SetItemString(py_sysinfo, "partnerhost", value);
	    //Py_DECREF(value);
		};
  }
  else {
    //PyDict_SetItemString(py_sysinfo, "partnerhost", PyString_FromStringAndSize(rfc_attributes.partner_host, strlen(rfc_attributes.partner_host)));
		value = PyString_FromStringAndSize(rfc_attributes.partner_host, strlen(rfc_attributes.partner_host));
    PyDict_SetItemString(py_sysinfo, "partnerhost", value);
	  //Py_DECREF(value);
	};

  //PyDict_SetItemString(py_sysinfo, "sysnr", PyString_FromStringAndSize(rfc_attributes.systnr, strlen(rfc_attributes.systnr)));
	value = PyString_FromStringAndSize(rfc_attributes.systnr, strlen(rfc_attributes.systnr));
  PyDict_SetItemString(py_sysinfo, "sysnr", value);
	//Py_DECREF(value);
  //PyDict_SetItemString(py_sysinfo, "sysid", PyString_FromStringAndSize(rfc_attributes.sysid, strlen(rfc_attributes.sysid)));
	value = PyString_FromStringAndSize(rfc_attributes.sysid, strlen(rfc_attributes.sysid));
  PyDict_SetItemString(py_sysinfo, "sysid", value);
	//Py_DECREF(value);
  //PyDict_SetItemString(py_sysinfo, "mandt", PyString_FromStringAndSize(rfc_attributes.client, strlen(rfc_attributes.client)));
	value = PyString_FromStringAndSize(rfc_attributes.client, strlen(rfc_attributes.client));
  PyDict_SetItemString(py_sysinfo, "mandt", value);
	//Py_DECREF(value);
  //PyDict_SetItemString(py_sysinfo, "user", PyString_FromStringAndSize(rfc_attributes.user, strlen(rfc_attributes.user)));
	value = PyString_FromStringAndSize(rfc_attributes.user, strlen(rfc_attributes.user));
  PyDict_SetItemString(py_sysinfo, "user", value);
	//Py_DECREF(value);
  //PyDict_SetItemString(py_sysinfo, "lang", PyString_FromStringAndSize(rfc_attributes.language, strlen(rfc_attributes.language)));
	value = PyString_FromStringAndSize(rfc_attributes.language, strlen(rfc_attributes.language));
  PyDict_SetItemString(py_sysinfo, "lang", value);
	//Py_DECREF(value);
  //PyDict_SetItemString(py_sysinfo, "isolang", PyString_FromStringAndSize(rfc_attributes.ISO_language, strlen(rfc_attributes.ISO_language)));
	value = PyString_FromStringAndSize(rfc_attributes.ISO_language, strlen(rfc_attributes.ISO_language));
  PyDict_SetItemString(py_sysinfo, "isolang", value);
	//Py_DECREF(value);
  if (rfc_attributes.trace == 'X') {
       //PyDict_SetItemString(py_sysinfo, "trace", PyString_FromStringAndSize("ON", 2));
			 value = PyString_FromStringAndSize("ON", 2);
       PyDict_SetItemString(py_sysinfo, "trace", value);
	     //Py_DECREF(value);
	}
  else {
       //PyDict_SetItemString(py_sysinfo, "trace", PyString_FromStringAndSize("OFF", 3));
			 value = PyString_FromStringAndSize("OFF", 3);
       PyDict_SetItemString(py_sysinfo, "trace", value);
	     //Py_DECREF(value);
	};

  //PyDict_SetItemString(py_sysinfo, "localcodepage", PyString_FromStringAndSize(rfc_attributes.own_codepage, strlen(rfc_attributes.own_codepage)));
	value = PyString_FromStringAndSize(rfc_attributes.own_codepage, strlen(rfc_attributes.own_codepage));
  PyDict_SetItemString(py_sysinfo, "localcodepage", value);
	//Py_DECREF(value);
  //PyDict_SetItemString(py_sysinfo, "partnercodepage", PyString_FromStringAndSize(rfc_attributes.partner_codepage, strlen(rfc_attributes.partner_codepage)));
	value = PyString_FromStringAndSize(rfc_attributes.partner_codepage, strlen(rfc_attributes.partner_codepage));
  PyDict_SetItemString(py_sysinfo, "partnercodepage", value);
	//Py_DECREF(value);
  if (rfc_attributes.rfc_role == RFC_ROLE_CLIENT) {
    //PyDict_SetItemString(py_sysinfo, "rfcrole", PyString_FromStringAndSize("External RFC Client", strlen("External RFC Client")));
		value = PyString_FromStringAndSize("External RFC Client", strlen("External RFC Client"));
    PyDict_SetItemString(py_sysinfo, "rfcrole", value);
	  //Py_DECREF(value);
	}
  else if (rfc_attributes.own_type == RFC_SERVER_EXT) {
    //PyDict_SetItemString(py_sysinfo, "rfcrole", PyString_FromStringAndSize("External RFC Server, started by SAP gateway", strlen("External RFC Server, started by SAP gateway")));
		value = PyString_FromStringAndSize("External RFC Server, started by SAP gateway", strlen("External RFC Server, started by SAP gateway"));
    PyDict_SetItemString(py_sysinfo, "rfcrole", value);
	  //Py_DECREF(value);
	}
  else {
    //PyDict_SetItemString(py_sysinfo, "rfcrole", PyString_FromStringAndSize("External RFC Server, registered at SAP gateway", strlen("External RFC Server, registered at SAP gateway")));
		value = PyString_FromStringAndSize("External RFC Server, registered at SAP gateway", strlen("External RFC Server, registered at SAP gateway"));
    PyDict_SetItemString(py_sysinfo, "rfcrole", value);
	  //Py_DECREF(value);
	};

  //PyDict_SetItemString(py_sysinfo, "rel", PyString_FromStringAndSize(rfc_attributes.own_rel, strlen(rfc_attributes.own_rel)));
	value = PyString_FromStringAndSize(rfc_attributes.own_rel, strlen(rfc_attributes.own_rel));
  PyDict_SetItemString(py_sysinfo, "rel", value);
	//Py_DECREF(value);

  if (rfc_attributes.partner_type == RFC_SERVER_R3) {
    // PyDict_SetItemString(py_sysinfo, "rfcpartner", PyString_FromStringAndSize("R3", 2));
		value = PyString_FromStringAndSize("R3", 2);
    PyDict_SetItemString(py_sysinfo, "rfcpartner", value);
	  //Py_DECREF(value);
	}
  else if (rfc_attributes.partner_type == RFC_SERVER_R2) {
    //PyDict_SetItemString(py_sysinfo, "rfcpartner", PyString_FromStringAndSize("R2", 2));
		value = PyString_FromStringAndSize("R2", 2);
    PyDict_SetItemString(py_sysinfo, "rfcpartner", value);
	  //Py_DECREF(value);
	}
  else if (rfc_attributes.rfc_role == RFC_ROLE_CLIENT)
  {
    if (rfc_attributes.partner_type == RFC_SERVER_EXT) {
      //PyDict_SetItemString(py_sysinfo, "rfcpartner", PyString_FromStringAndSize("External RFC Server, started by SAP gateway", strlen("External RFC Server, started by SAP gateway")));
			value = PyString_FromStringAndSize("External RFC Server, started by SAP gateway", strlen("External RFC Server, started by SAP gateway"));
      PyDict_SetItemString(py_sysinfo, "rfcpartner", value);
	    //Py_DECREF(value);
		}
    else {
      //PyDict_SetItemString(py_sysinfo, "rfcpartner", PyString_FromStringAndSize("External RFC Server, registered at SAP gateway", strlen("External RFC Server, registered at SAP gateway")));
			value = PyString_FromStringAndSize("External RFC Server, registered at SAP gateway", strlen("External RFC Server, registered at SAP gateway"));
      PyDict_SetItemString(py_sysinfo, "rfcpartner", value);
	    //Py_DECREF(value);
		}
  }
  else {
    //PyDict_SetItemString(py_sysinfo, "rfcpartner", PyString_FromStringAndSize("External RFC Client", strlen("External RFC Client")));
		value = PyString_FromStringAndSize("External RFC Client", strlen("External RFC Client"));
    PyDict_SetItemString(py_sysinfo, "rfcpartner", value);
	  //Py_DECREF(value);
	};

  //PyDict_SetItemString(py_sysinfo, "partnerrel", PyString_FromStringAndSize(rfc_attributes.partner_rel, strlen(rfc_attributes.partner_rel)));
	value = PyString_FromStringAndSize(rfc_attributes.partner_rel, strlen(rfc_attributes.partner_rel));
  PyDict_SetItemString(py_sysinfo, "partnerrel", value);
	//Py_DECREF(value);
  //PyDict_SetItemString(py_sysinfo, "kernelrel", PyString_FromStringAndSize(rfc_attributes.kernel_rel, strlen(rfc_attributes.kernel_rel)));
	value = PyString_FromStringAndSize(rfc_attributes.kernel_rel, strlen(rfc_attributes.kernel_rel));
  PyDict_SetItemString(py_sysinfo, "kernelrel", value);
	//Py_DECREF(value);
  //PyDict_SetItemString(py_sysinfo, "convid", PyString_FromStringAndSize(rfc_attributes.CPIC_convid, strlen(rfc_attributes.CPIC_convid)));
	value = PyString_FromStringAndSize(rfc_attributes.CPIC_convid, strlen(rfc_attributes.CPIC_convid));
  PyDict_SetItemString(py_sysinfo, "convid", value);
	//Py_DECREF(value);

  return;
}



/*
 * Generic Inbound RFC Request Handler
 *
 */
static RFC_RC DLL_CALL_BACK_FUNCTION handle_request(  RFC_HANDLE handle, PyObject *py_iface )
{
    RFC_PARAMETER parameter[MAX_PARA];
    RFC_TABLE     table[MAX_PARA];
    RFC_RC        rc = 0;
    int           res,
                  tab_cnt, 
                  imp_cnt,
                  exp_cnt,
                  irow,
                  tab_index,
                  a_index,
                  i,
                  j;

    PyObject *function, *parms, *parmsidx, *tabarray, *aentry, *tabentry, *py_sysinfo;
    PyObject *ptype, *pname, *plen, *pintype;
    PyObject *py_rvalue, *py_evalue, *value, *py_trfc, *py_handler;


    if (!(function = PyObject_GetAttrString(py_iface, "name")))
      return -1;
    if (!(parms = PyObject_GetAttrString(py_iface, "parms")))
      return -1;
    if (!(parmsidx = PyObject_GetAttrString(py_iface, "parmsindex")))
      return -1;
    if (!(py_sysinfo = PyObject_GetAttrString(global_saprfc, "sysinfo")))
      return -1;
    a_index = PyList_Size(parms);

    tab_cnt = 0;
    exp_cnt = 0;
    imp_cnt = 0;

    /* get the RFC interface definition hash  and iterate   */
   for (i = 0; i < a_index; i++) {

     aentry = PyList_GetItem(parms, i);
     pname = PyObject_GetAttrString(aentry, "name");
     ptype = PyObject_GetAttrString(aentry, "type");
     plen = PyObject_GetAttrString(aentry, "len");
     pintype = PyObject_GetAttrString(aentry, "intype");

       switch ( PyInt_AsLong(ptype) ){
	       case RFCIMPORT:
	         parameter[imp_cnt].name = malloc( strlen(PyString_AsString(pname)) + 1 );
	         if ( parameter[imp_cnt].name == NULL )
               return 0;
	         memset(parameter[imp_cnt].name, 0, strlen(PyString_AsString(pname)) + 1);
	         memcpy(parameter[imp_cnt].name, PyString_AsString(pname), strlen(PyString_AsString(pname)));
	         parameter[imp_cnt].nlen = strlen(PyString_AsString(pname));
	         parameter[imp_cnt].addr = make_space( PyInt_AsLong(plen) );
	         parameter[imp_cnt].leng = PyInt_AsLong(plen);
	         parameter[imp_cnt].type = PyInt_AsLong(pintype);
	         ++imp_cnt;
	         break;

         case RFCEXPORT:
	         break;

	       case RFCTABLE:
	         table[tab_cnt].name = malloc( strlen(PyString_AsString(pname)) + 1 );
	         if ( table[tab_cnt].name == NULL )
               return 0;
	         memset(table[tab_cnt].name, 0, strlen(PyString_AsString(pname)) + 1);
	         memcpy(table[tab_cnt].name, PyString_AsString(pname), strlen(PyString_AsString(pname)));
	         table[tab_cnt].nlen = strlen(PyString_AsString(pname));
	         table[tab_cnt].leng = PyInt_AsLong(plen);
           table[tab_cnt].itmode = RFC_ITMODE_BYREFERENCE;
           table[tab_cnt].type = RFCTYPE_CHAR; 
	         tab_cnt++;

	         break;
	       default:
	         fprintf(stderr, "    I DONT KNOW WHAT THIS PARAMETER IS: %s \n", PyString_AsString(pname));
           exit(0);
	         break;
      };
     Py_DECREF(pname);
     Py_DECREF(ptype);
     Py_DECREF(plen);
     Py_DECREF(pintype);

   };

    parameter[imp_cnt].name = NULL;
    parameter[imp_cnt].nlen = 0;
    parameter[imp_cnt].leng = 0;
    parameter[imp_cnt].addr = NULL;
    parameter[imp_cnt].type = 0;

    table[tab_cnt].name = NULL;
    table[tab_cnt].ithandle = NULL;
    table[tab_cnt].nlen = 0;
    table[tab_cnt].leng = 0;
    table[tab_cnt].type = 0;

    rc = RfcGetData( handle, parameter, table );
    if( rc != RFC_OK ) return rc;

    for (imp_cnt = 0; imp_cnt < MAX_PARA; imp_cnt++){
       if ( parameter[imp_cnt].name == NULL ){
	       break;
       };
       aentry = PyDict_GetItemString(parmsidx, parameter[imp_cnt].name);
       Py_INCREF(aentry);
       value = PyString_FromStringAndSize(parameter[imp_cnt].addr, parameter[imp_cnt].leng);
       //PyObject_SetAttrString(aentry, "value", PyString_FromStringAndSize(parameter[imp_cnt].addr, parameter[imp_cnt].leng));
       PyObject_SetAttrString(aentry, "value", value);
			 Py_DECREF(value);
       free(parameter[imp_cnt].name);
       
       parameter[imp_cnt].name = NULL;
       parameter[imp_cnt].nlen = 0;
       parameter[imp_cnt].leng = 0;
       parameter[imp_cnt].type = 0;
       if ( parameter[imp_cnt].addr != NULL ){
	       free(parameter[imp_cnt].addr);
       };
       parameter[imp_cnt].addr = NULL;

    };
   
    for (tab_cnt = 0; tab_cnt < MAX_PARA; tab_cnt++){
       if ( table[tab_cnt].name == NULL ){
	       break;
       };
       aentry = PyDict_GetItemString(parmsidx, table[tab_cnt].name);
       Py_INCREF(aentry);
       tabarray = PyList_New(ItFill(table[tab_cnt].ithandle));
       for (irow = 1; irow <=  ItFill(table[tab_cnt].ithandle); irow++){
           PyList_SetItem( tabarray, irow - 1, 
                        PyString_FromStringAndSize( ItGetLine( table[tab_cnt].ithandle, irow ), 
	    	                    table[tab_cnt].leng ) );
       };
       PyObject_SetAttrString(aentry, "value", tabarray);
			 Py_DECREF(tabarray);
       free(table[tab_cnt].name);
       table[tab_cnt].name = NULL;
       if ( table[tab_cnt].ithandle != NULL ){
	       ItFree( table[tab_cnt].ithandle );
       };
       table[tab_cnt].ithandle = NULL;
       table[tab_cnt].nlen = 0;
       table[tab_cnt].leng = 0;
       table[tab_cnt].type = 0;

    };

    /* get the systeminfo of the current connection */
    get_attributes(handle, py_sysinfo);

    if (!(py_handler = PyObject_GetAttrString(py_iface, "callback")))
      return RFC_SYS_EXCEPTION;
    Py_XINCREF(py_handler);
    py_trfc = PyObject_GetAttrString(global_saprfc, "trfc");
    if (PyObject_IsTrue(py_trfc)){
      py_rvalue = PyObject_CallMethod(py_handler, "handler", "(OOS)", py_iface, global_saprfc, PyString_FromString(current_tid));
    } else {
      py_rvalue = PyObject_CallMethod(py_handler, "handler", "(OO)",py_iface, global_saprfc);
    }
    Py_DECREF(py_trfc);

    if (py_rvalue == NULL){
       RfcRaise( handle, "HANDLER_CALLBACK_ERROR" );
       PyErr_Format(PyExc_TypeError, "Loop Callback Error - no return value (3)");
       return RFC_SYS_EXCEPTION;
    }
    res = PyInt_AsLong(py_rvalue);
    //Py_DECREF(py_rvalue);
    if (res < 0){
      py_evalue = PyObject_GetAttrString(py_iface, "error");
      //Py_DECREF(py_evalue);
      if (PyObject_IsTrue(py_evalue)){
        RfcRaise( handle, PyString_AsString(py_evalue));
      }
      return RFC_SYS_EXCEPTION;
    }

    exp_cnt = 0;
    tab_cnt = 0;
    for (i = 0; i < a_index; i++) {
      aentry = PyList_GetItem(parms,i);
      pname = PyObject_GetAttrString(aentry, "name");
      ptype = PyObject_GetAttrString(aentry, "type");
      pintype = PyObject_GetAttrString(aentry, "intype");
      plen = PyObject_GetAttrString(aentry, "len");

      switch ( (int) PyInt_AsLong(ptype) ){
	      case RFCEXPORT:
	        parameter[exp_cnt].name = malloc( strlen(PyString_AsString(pname)) + 1);
	        if ( parameter[exp_cnt].name == NULL )
                 return RFC_SYS_EXCEPTION;
	        memset(parameter[exp_cnt].name, 0, strlen(PyString_AsString(pname)) + 1);
	        memcpy(parameter[exp_cnt].name, PyString_AsString(pname), strlen(PyString_AsString(pname)));
	        parameter[exp_cnt].nlen = strlen(PyString_AsString(pname));
             value = PyObject_GetAttrString(aentry, "value");
             //Py_DECREF(value);
	        if (! PyObject_IsTrue(value))
	           break;
          parameter[exp_cnt].addr = MyValue(  (int) PyInt_AsLong(pintype),
 	       			       PyString_AsString(value),
	         		       (int) PyInt_AsLong(plen), true );

	        parameter[exp_cnt].leng = (int) PyInt_AsLong(plen);
	        parameter[exp_cnt].type = (int) PyInt_AsLong(pintype);
	        ++exp_cnt;
	        break;

	      case RFCTABLE:
	        table[tab_cnt].name = malloc( strlen(PyString_AsString(pname)) + 1);
	        if ( table[tab_cnt].name == NULL )
                 return RFC_SYS_EXCEPTION;
	        memset(table[tab_cnt].name, 0, strlen(PyString_AsString(pname)) + 1);
	        memcpy(table[tab_cnt].name, PyString_AsString(pname), strlen(PyString_AsString(pname)));
	        table[tab_cnt].nlen = strlen(PyString_AsString(pname));
	        table[tab_cnt].leng = (int) PyInt_AsLong(plen);
          table[tab_cnt].itmode = RFC_ITMODE_BYREFERENCE;
          table[tab_cnt].type = RFCTYPE_CHAR; 
          table[tab_cnt].ithandle = 
	         ItCreate( table[tab_cnt].name, (int) PyInt_AsLong(plen), 0 , 0 );
	        if ( table[tab_cnt].ithandle == NULL )
                 return RFC_SYS_EXCEPTION;

          value = PyObject_GetAttrString(aentry, "value");
             //Py_DECREF(value);
	        if (PyObject_IsTrue(value) && PyList_Check(value)){
            tab_index = PyList_Size(value);
	          for (j = 0; j < tab_index; j++) {
               tabentry = PyList_GetItem(value,j);
	             memcpy(ItAppLine(table[tab_cnt].ithandle),
	                    PyString_AsString(tabentry),
		           table[tab_cnt].leng);
	          };
	        }
	        tab_cnt++;
	        break;
	      default:
	        break;
      };
      Py_DECREF(pname);
      Py_DECREF(ptype);
      Py_DECREF(pintype);
      Py_DECREF(plen);
    };

    /* tack on a NULL value parameter to each type to signify that there are no more */
    parameter[exp_cnt].name = NULL;
    parameter[exp_cnt].nlen = 0;
    parameter[exp_cnt].leng = 0;
    parameter[exp_cnt].addr = NULL;
    parameter[exp_cnt].type = 0;

    table[tab_cnt].name = NULL;
    table[tab_cnt].ithandle = NULL;
    table[tab_cnt].nlen = 0;
    table[tab_cnt].leng = 0;
    table[tab_cnt].type = 0;

    rc = RfcSendData( handle, parameter, table );
    Py_DECREF(function);
    Py_DECREF(parms);
    Py_DECREF(parmsidx);
    Py_DECREF(py_sysinfo);

    return rc;
}


static RFC_RC DLL_CALL_BACK_FUNCTION do_docu(  RFC_HANDLE handle )
{
    RFC_PARAMETER parameter[1];
    RFC_TABLE     table[2];
    RFC_RC        rc = 0;
    PyObject      *aentry;
    int           a_index;
    int i;

    parameter[0].name = NULL;
    parameter[0].nlen = 0;
    parameter[0].leng = 0;
    parameter[0].addr = NULL;
    parameter[0].type = 0;

    table[0].name =  malloc( 5 );
    memset(table[0].name, 0, 5);
    sprintf(table[0].name, "DOCU");
    table[0].nlen = 4;
    table[0].type = RFCTYPE_CHAR;
    table[0].leng = 80;
    table[0].itmode = RFC_ITMODE_BYREFERENCE;

    table[1].name = NULL;
    table[1].ithandle = NULL;
    table[1].nlen = 0;
    table[1].leng = 0;
    table[1].type = 0;

    rc = RfcGetData( handle, parameter, table );
    if( rc != RFC_OK ) return rc;

    parameter[0].name = NULL;
    parameter[0].nlen = 0;
    parameter[0].leng = 0;
    parameter[0].addr = NULL;
    parameter[0].type = 0;

    table[0].name =  malloc( 5 );
    memset(table[0].name, 0, 5);
    sprintf(table[0].name, "DOCU");
    table[0].nlen = 4;
    table[0].type = RFCTYPE_CHAR;
    table[0].leng = 80;
    table[0].itmode = RFC_ITMODE_BYREFERENCE;

    table[1].name = NULL;
    table[1].ithandle = NULL;
    table[1].nlen = 0;
    table[1].leng = 0;
    table[1].type = 0;
    table[0].ithandle = ItCreate( table[0].name, 80, 0 , 0 );

    /* get the documentation out of the array */
    a_index = PyList_Size(py_store_docu);

    /* get the RFC interface definition array and iterate   */
    for (i = 0; i < a_index; i++) {
      aentry = PyList_GetItem(py_store_docu, i);
      sprintf(ItAppLine( table[0].ithandle ), "%s", PyString_AsString(aentry));
    };

    rc = RfcSendData( handle, parameter, table );

    return rc;
}


/*
 *
 * function module documentation
 *
 */

/*
 * insert newline characters to start a new line
 */
#undef  NL
#define NL "\n"

static char * do_docu_docu( void )
{
   static char docu[] =
 "This is the override function for the standard self         "      NL
 "discovery documentation function.              "                   NL
 ""                                                                  NL
 "IMPORTING"                                                         NL
 "TABLES"                                                            NL
 "  DOCU           C(80)"                                            NL
 "    internal table contains the documentaiton data.          "     NL
   ;

   return docu;
}




static struct PyMethodDef saprfcutil_methods[] = {
    {"connect", saprfcutil_connect, METH_VARARGS},
    {"call_receive", saprfcutil_call_receive, METH_VARARGS},
    {"accept", saprfcutil_accept, METH_VARARGS},
    {"close", saprfcutil_close, METH_VARARGS},
    {"get_ticket", saprfcutil_get_ticket, METH_VARARGS},
    {NULL, NULL}
};


void initsaprfcutil()
{
    (void) Py_InitModule("saprfcutil", saprfcutil_methods);
}


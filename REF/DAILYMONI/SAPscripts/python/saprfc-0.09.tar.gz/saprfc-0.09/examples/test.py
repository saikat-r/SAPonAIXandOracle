#!/usr/bin/env /usr/bin/python2.2
import sys
if sys.version < '2.2':
	print "\n\n   You Must Have Python Version >= 2.2  To run saprfc \n\n"
	sys.exit(1)
import os
path = ""
if 'build' in os.listdir(os.getcwd()):
	path = os.path.join(os.getcwd(), 'build')
elif os.listdir(os.path.join(os.getcwd(), '../')):
	path = os.path.join(os.getcwd(), '../build')
else:
	print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
	print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
	sys.exit(1)

libdir = ""
for i in  os.listdir(path):
	if i.startswith("lib"):
		libdir = os.path.join(path, i)
if libdir == "":
	print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
	print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
	sys.exit(1)
sys.path.append(libdir)
print "using library path: " + libdir


import saprfc
#conn = saprfc.conn(ashost='kogut.local.net', sysnr='18', passwd='19920706')
#conn = saprfc.conn(ashost='seahorse.local.net', sysnr='00', client='010', lang='EN', user='developer', passwd='developer')

ticket = 'AjExMDABAAxERVZFTE9QRVIgICACAAMwMTADAAhOVzQgICAgIAQADDIwMDYwNDEyMTgzNgUABAAAADwGAAFYCQABRQoADERFVkVMT1BFUiAgIAsAA05XNAwACE5XNCAgICAgDQAMMjAwNjA0MTIxODM2DgAA/wKCMIICfgYJKoZIhvcNAQcCoIICbzCCAmsCAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHAaCCAYcwggGDMIIBQQIBADAJBgcqhkjOOAQDMA4xDDAKBgNVBAMTA05XNDAeFw05NzEwMDEwMDAwMDBaFw0zODAxMDEwMDAwMDBaMA4xDDAKBgNVBAMTA05XNDCB8DCBqAYHKoZIzjgEATCBnAJBAP/46hFIJ89LHysYnzTpBomPglId/04kO5vr7CbjNfbj74gk/83cHwhzwCkmnMkMiiUZq6iJQpLAA4lZeF0txdMCFQC5DVWzaYFumgjTmi4PJaEyn1WrhwJAO78ebowwL7synjQCCzSqv8cPTf2GTK/I!EEL/Mtwvw7cC7cGwVScKO/W!n7cjL1KI6v287/v3mmYYoQbgH4tBgNDAAJAMWfyy/neoPZ5wDZo5Lm528t6hFlIqsqaOe96mdiEQX31NWRMOEnm6aWJKogTxmiteHktU2PXMQ9Mlou9FGCoJjAJBgcqhkjOOAQDAzEAMC4CFQCQTI5l/qDFBt2Qy9SdcjE1U8ceFAIVAJWRXWhL50f76LXycnqi3uk5geSTMYHAMIG9AgEBMBMwDjEMMAoGA1UEAxMDTlc0AgEAMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wNjA0MTIxODM2MzNaMCMGCSqGSIb3DQEJBDEWBBSixXk2uLkfPb39kKfbhuSQnqpCSDAJBgcqhkjOOAQDBC4wLAIULpuvkUUkrjB5Zsx4cwP55jLPCWwCFCNAPpntGwE8Ax!f7c/30NznQRNk'

#conn = saprfc.conn(ashost='seahorse.local.net', sysnr='00', client='010', lang='EN', mysapsso2=ticket, trace=1)
#conn = saprfc.conn(ashost='seahorse.local.net', sysnr='00', client='010', lang='EN', user='developer', passwd='developer', getsso2=1)
conn = saprfc.conn(ashost='seahorse.local.net', sysnr='00', client='010', lang='EN', user='developer', passwd='developer')
conn.connect()

#print conn.get_ticket()

#sys.exit(1)

print "am I connected: ", conn.is_connected()
print "sysinfo is: ", conn.sapinfo()


print "go into loop \n"

iface = conn.discover("RFC_READ_TABLE")
j = 0

while j < 100:
	print j
	j += 1
	iface.query_table.setValue("TRDIR")
	iface.ROWCOUNT.setValue(100)
	iface.OPTIONS.setValue( ["NAME LIKE 'SAPL%RFC%'"] )
	print "going to make the call...\n"
	conn.callrfc( iface )
	print "back from  call...\n"
	print "NO. PROGS: ", iface.DATA.rowCount(), " \n"
	print "PROGS DATA: ", iface.DATA.value, " \n"
	# get the SAP Data Dictionary structure for TRDIR
	str = conn.structure("TRDIR")
	# various ways for iterating over the results in an
	#  interface table
	for x in iface.data.value:
		print "Doing: " + str.toHash(x)['NAME']

	print "PROGS HASH ROWS: "
	for i in iface.DATA.hashRows():
		print "next row: ", i


conn.close()


# these will not work on your system as only I have Z_TEST
if conn.ashost != "kogut.local.net":
	sys.exit(0)
itest = conn.discover("Z_TEST")
itest.chr1.setValue("wibble")
itest.int11.setValue( 3 )
itest.int21.setValue( 45 )
itest.int41.setValue( 134567 )
itest.num1.setValue( 3456 )
itest.cur1.setValue( 134567.23 )
itest.qty1.setValue( -112227.234 )
itest.flt1.setValue( 112227.234 )
conn.callrfc(itest)

print "RESULT: "
print "chr2: ", itest.chr2.getValue()
print "int1: ", itest.int12.getValue()
print "int2: ", itest.int22.getValue()
print "int4: ", itest.int42.getValue()
print "num2: ", itest.num2.getValue()
print "cur2: ", itest.cur2.getValue()
print "qty2: ", itest.qty2.getValue()
print "flt2: ", itest.flt2.getValue()
print "long char: " + itest.lchar.getValue() + "#\n with a length of: ", len( itest.lchar.getValue() )

conn.close()

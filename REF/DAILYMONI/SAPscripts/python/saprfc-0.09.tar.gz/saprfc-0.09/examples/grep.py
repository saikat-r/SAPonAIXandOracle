from __future__ import generators
import sys, re
import fileinput

def grep(seq, regex):
    "yields items from seq that match regex"

    regex = re.compile(regex)
    for line in seq:
        if regex.search(line):
            yield line

if __name__ == '__main__':
    regex = sys.argv.pop(1)
    input = fileinput.input()
    for line in grep(input, regex):
        sys.stdout.write(line)

#!/usr/bin/env /usr/bin/python2.3
class reg:

	def __init__(self):
		self.cnt = 0
		import sys
		import os

	def LoopHandler(self, srfc):
		self.cnt += 1
		print "inside the customer loop handler - iter: %d ...\n" % self.cnt
		if self.cnt >= 300:
			return -1
		return 1

	def handler(self, iface, srfc, tid):
		data = []
		print "TID (reg.handler) is: #" + tid + "#"
		print "COMMAND is: #" + iface.COMMAND.getValue() + "#"
		out = os.popen(iface.COMMAND.getValue(), "r")
		for row in out:
			data.append(row)
		out.close()
		iface.PIPEDATA.setValue( data )
		return 1

	def TRFCCheck(self, srfc, tid):
		print "TID (TRFCCheck) is: #" + tid + "#"
		return False

	def TRFCCommit(self, srfc, tid):
		print "TID (TRFCCommit) is: #" + tid + "#"
		return

	def TRFCConfirm(self, srfc, tid):
		print "TID (TRFCConfirm) is: #" + tid + "#"
		return

	def TRFCRollback(self, srfc, tid):
		print "TID (TRFCRollback) is: #" + tid + "#"
		return

if __name__ == "__main__":
	import sys
	if sys.version < '2.2':
		print "\n\n   You Must Have Python Version >= 2.2  To run saprfc \n\n"
		sys.exit(1)
	import os
	path = ""
	if 'build' in os.listdir(os.getcwd()):
		path = os.path.join(os.getcwd(), 'build')
	elif os.listdir(os.path.join(os.getcwd(), '../')):
		path = os.path.join(os.getcwd(), '../build')
	else:
		print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
		print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
		sys.exit(1)

	libdir = ""
	for i in  os.listdir(path):
		if i.startswith("lib"):
			libdir = os.path.join(path, i)
	if libdir == "":
		print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
		print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
		sys.exit(1)

	sys.path.append(libdir)

	print "using library path: " + libdir


	import saprfc

	cb = reg()

	conn = saprfc.conn(gwhost='seahorse.local.net', gwserv='3300', tpname='wibble.rfcexec', trfc=cb)

	ifc = saprfc.iface("RFC_REMOTE_PIPE", callback=cb)
	ifc.addParm( saprfc.parm("COMMAND", "", saprfc.RFCIMPORT, saprfc.RFCTYPE_CHAR, 256))
	ifc.addParm( saprfc.parm("READ", "", saprfc.RFCIMPORT, saprfc.RFCTYPE_CHAR, 1))
	ifc.addParm( saprfc.tab("PIPEDATA", "", 80))

	conn.iface(ifc)

	conn.accept(callback=cb, wait=5)
	#conn.accept(wait=3)
	print "All finished (trfc_reg.py) \n"


#!/usr/bin/env /usr/bin/python2.2
import sys
if sys.version < '2.2':
	print "\n\n   You Must Have Python Version >= 2.2  To run saprfc \n\n"
	sys.exit(1)
import os
path = ""
if 'build' in os.listdir(os.getcwd()):
	path = os.path.join(os.getcwd(), 'build')
elif os.listdir(os.path.join(os.getcwd(), '../')):
	path = os.path.join(os.getcwd(), '../build')
else:
	print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
	print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
	sys.exit(1)

libdir = ""
for i in  os.listdir(path):
	if i.startswith("lib"):
		libdir = os.path.join(path, i)
if libdir == "":
	print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
	print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
	sys.exit(1)

sys.path.append(libdir)


import saprfc

conn = saprfc.conn(ashost='kogut.local.net', sysnr='18', passwd='19920706')
conn.connect()

i = conn.discover("Z_ORDERS")
oh = i.ORDERS.structure
oh.PARTNER.value = 'V002'
oh.HDRTEXT.value = 'Get me some books please'
oh.DATUM.value = '20030609'
oh.UZEIT.value = '110000'
i.ORDERS.setValue( [ oh.Value() ] )

items = []
oi = i.ORDERITEMS.structure
oi.MATERIAL.value = 'M002'
oi.PRICE.value = 92
oi.QUANTITY.value = 3
items.append(oi.Value())
oi.MATERIAL.value = 'M001'
oi.PRICE.value = 12
oi.QUANTITY.value = 5
items.append(oi.Value())
i.ORDERITEMS.setValue( items )

conn.callrfc( i )

print "RESULTS: ", i.ORDERS.value, " \n"
for x in i.ORDERS.hashRows():
  print x['PONR']

conn.close()


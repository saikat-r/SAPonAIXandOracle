#!/usr/bin/env /usr/bin/python2.3
class reg:

#	def __init__(self, host="localhost", user="root", passwd="mental", dbase="USOrders"):
	def __init__(self, host="serv00.bydeluxe.net", user="root", passwd="mental", dbase="mysql"):
		self.cnt = 0
		import MySQLdb
		self.host = str(host)
		self.user = str(user)
		self.passwd = str(passwd)
		self.dbase = str(dbase)
		self.db = MySQLdb.connect(self.host, self.user, self.passwd, self.dbase)

	def LoopHandler(self, srfc):
		self.cnt += 1
		print "inside the customer loop handler - iter: %d ...\n" % self.cnt
		if self.cnt >= 500:
			self.db.close()
			return -1
		return 1

	def handler(self, iface, srfc):
		query = ""
		delim = iface.DELIMITER.getValue()
		for i in iface.OPTIONS.value:
			print i
			query += " " + i.rstrip()
		print "The whole query: " + query
		c = self.db.cursor()
		c.execute(query)
		rows = []
		for line in c.fetchall():
			row = []
			for i in line:
				row.append(str(i))
			rows.append(delim.join(row))
		iface.DATA.setValue( rows )
		print "all done returning .."
		return 1


if __name__ == "__main__":
#   bunf to sort out the library path
	import sys
	import os
	path = ""
	if 'build' in os.listdir(os.getcwd()):
		path = os.path.join(os.getcwd(), 'build')
	elif os.listdir(os.path.join(os.getcwd(), '../')):
		path = os.path.join(os.getcwd(), '../build')
	else:
		print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
		print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
		sys.exit(1)
	libdir = ""
	for i in  os.listdir(path):
		if i.startswith("lib"):
			libdir = os.path.join(path, i)
	if libdir == "":
		print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
		print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
		sys.exit(1)
	sys.path.append(libdir)


#   This is where it really begins
	import saprfc

#	conn = saprfc.conn(gwhost='seahorse.local.net', gwserv='3300', tpname='mysql')
	conn = saprfc.conn(gwhost='172.22.50.1', gwserv='3300', tpname='wibbe.rfcexec')
	cb = reg()
	ifc = saprfc.iface("RFC_READ_TABLE", callback=cb)
	ifc.addParm( saprfc.parm("QUERY_TABLE", "", saprfc.RFCIMPORT, saprfc.RFCTYPE_CHAR, 30))
	ifc.addParm( saprfc.parm("DELIMITER", "", saprfc.RFCIMPORT, saprfc.RFCTYPE_CHAR, 1))
	ifc.addParm( saprfc.parm("ROWSKIPS", "", saprfc.RFCIMPORT, saprfc.RFCTYPE_INT, 4, 0, 0, 0))
	ifc.addParm( saprfc.parm("ROWCOUNT", "", saprfc.RFCIMPORT, saprfc.RFCTYPE_INT, 4, 0, 0, 0))
	ifc.addParm( saprfc.tab("FIELDS", "", 103))
	ifc.addParm( saprfc.tab("OPTIONS", "", 72))
	ifc.addParm( saprfc.tab("DATA", "", 512))

	conn.iface(ifc)

	conn.accept(callback=cb, wait=10)
	print "All finished (mysql.py) \n"


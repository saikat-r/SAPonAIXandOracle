#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
if sys.version < '2.2':
  print "\n\n   You Must Have Python Version >= 2.2  To run saprfc \n\n"
  sys.exit(1)
import os
path = ""
if 'build' in os.listdir(os.getcwd()):
  path = os.path.join(os.getcwd(), 'build')
elif os.listdir(os.path.join(os.getcwd(), '../')):
  path = os.path.join(os.getcwd(), '../build')
else:
  print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
  print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
  sys.exit(1)

libdir = ""
for i in  os.listdir(path):
  if i.startswith("lib"):
    libdir = os.path.join(path, i)
if libdir == "":
  print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
  print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
  sys.exit(1)
sys.path.append(libdir)
print "using library path: " + libdir

import time
import saprfc
import gc

import sys
import types

# Recursively expand slist's objects
# into olist, using seen to track
# already processed objects.
def _getr(slist, olist, seen):
  for e in slist:
    if id(e) in seen:
      continue
    seen[id(e)] = None
    olist.append(e)
    tl = gc.get_referents(e)
    if tl:
      _getr(tl, olist, seen)

# The public function.
def get_all_objects():
  """Return a list of all live Python
  objects, not including the list itself."""
  gcl = gc.get_objects()
  olist = []
  seen = {}
  # Just in case:
  seen[id(gcl)] = None
  seen[id(olist)] = None
  seen[id(seen)] = None
  # _getr does the real work.
  _getr(gcl, olist, seen)
#  return olist
  print "\n\n\nObjects\n==============\n"
  for i in olist:
    print type(i)



def get_refcounts():
    d = {}
    sys.modules
    # collect all classes
    for m in sys.modules.values():
        for sym in dir(m):
            o = getattr (m, sym)
            if type(o) is types.ClassType:
                d[o] = sys.getrefcount (o)
    # sort by refcount
    pairs = map (lambda x: (x[1],x[0]), d.items())
    pairs.sort()
    pairs.reverse()
    return pairs

def print_top_100():
    for n, c in get_refcounts()[:100]:
        print '%10d %s' % (n, c.__name__)


def main(args):
    gc.enable()
    gc.set_debug(gc.DEBUG_LEAK)
    i = 0
#    while i < 10000:
    while i < 1000:
        print i
        i += 1
        sap = saprfc.conn(ashost = "seahorse.local.net", sysnr = "00", client = "010", user = "developer", lang="E", passwd = "developer", trace="0")
#        sap = saprfc.conn(ashost = "172.22.50.1", sysnr = "00", client = "200", user = "harding_p", lang="E", passwd = "tw4ddle", trace="0")
        sap.connect()
        sap.sapinfo()
        sap.discover("RFCPING")
        sap.close()
        if i == 1:
            time.sleep(5)
    #print_top_100()
    #get_all_objects()
        print "gc.collect() = " + str(gc.collect())
        print "len(gc.garbage) = " + str(len(gc.garbage))


if __name__ == "__main__":
    main(sys.argv)


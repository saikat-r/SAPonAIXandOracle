#!/usr/bin/env /usr/bin/python2.2
import sys
if sys.version < '2.2':
	print "\n\n   You Must Have Python Version >= 2.2  To run saprfc \n\n"
	sys.exit(1)
import os
path = ""
if 'build' in os.listdir(os.getcwd()):
	path = os.path.join(os.getcwd(), 'build')
elif os.listdir(os.path.join(os.getcwd(), '../')):
	path = os.path.join(os.getcwd(), '../build')
else:
	print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
	print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
	sys.exit(1)
libdir = ""
for i in  os.listdir(path):
	if i.startswith("lib"):
		libdir = os.path.join(path, i)
if libdir == "":
	print "cant find ./build directory to load the saprfc module, try runnig from the package root dir"
	print "   looked in:", os.getcwd(), " and ", os.path.join(os.getcwd(), '../')
	sys.exit(1)
sys.path.append(libdir)
print "using library path: " + libdir


import saprfc

#conn = saprfc.conn(ashost='kogut.local.net', sysnr='18', passwd='19920706')
conn = saprfc.conn(ashost='seahorse.local.net')
conn.connect()
print "am I connected: ", conn.is_connected()
print "sysinfo is: ", conn.sapinfo()

iface = conn.discover("RFC_READ_TABLE")
iface.query_table.setValue("TRDIR")
iface.ROWCOUNT.setValue(50)
iface.OPTIONS.setValue( ["NAME LIKE 'RS%'"] )

conn.callrfc( iface )

print "NO. PROGS: ", iface.DATA.rowCount(), " \n"

# get the SAP Data Dictionary structure for TRDIR
str = conn.structure("TRDIR")

reps = conn.discover("RFC_READ_REPORT")
# various ways for iterating over the results in an
#  interface table
c = 0
for x in iface.data.value:
  c += 1
  reps.PROGRAM.setValue(str.toHash(x)['NAME'])
  conn.callrfc( reps )
  print c, " ROWS: ", str.toHash(x)['NAME'], " - ", reps.QTAB.rowCount(), " \n"
  reps.QTAB.empty()

conn.close()

#! /usr/bin/python2.3

import sys
if sys.version < '2.3':
	print "\n\n   You Must Have Python Version >= 2.3  To Install saprfc \n\n"
	sys.exit(1)


from distutils.core import setup, Extension
incdirs = []
libdirs = []
libs = []
if sys.platform=='win32':
	print "selecting win32 libraries...\n"
	incdirs = ['src/rfcsdk/include']
	libdirs = ['src/rfcsdk/lib']
	libs = ['librfc32']
else:
	incdirs = ['/usr/sap/rfcsdk/include']
	libdirs = ['/usr/sap/rfcsdk/lib']
	libs = ['rfccm', 'pthread', 'dl', 'm', 'c']


saprfcutil_ext = Extension('saprfcutil',
                    include_dirs = incdirs,
                    library_dirs = libdirs,
                    libraries = libs,
                    sources = ['src/saprfcutil.c'])


setup(name = "saprfc", version = "0.09",
      description="SAP R/3 RFC language binding for Python",
      author="Piers Harding",
      author_email="piers@ompa.net",
      url="http://www.piersharding.com/download/",
      py_modules = ['saprfc'],
      ext_modules = [saprfcutil_ext])


:orphan:

.. _glossary:

========
Glossary
========

.. glossary::
  :sorted:

  test
    This is a test entry

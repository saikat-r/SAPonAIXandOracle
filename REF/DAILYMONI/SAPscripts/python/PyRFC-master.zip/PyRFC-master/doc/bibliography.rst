============
Bibliography
============


.. _c09a:

Schmidt and Li (2009a)
----------------------
Improve communication between your C/C++ applications and SAP systems with SAP NetWeaver RFC SDK - 
`Part 1: RFC Client Programming <https://scn.sap.com/docs/DOC-52886>`_, 
*SAP Professional Journal*, pp 1-16 (originally published in November 2007)

.. _c09b:

Schmidt and Li (2009b)
----------------------
Improve communication between your C/C++ applications and SAP systems with SAP NetWeaver RFC SDK - 
- `Part 2: RFC Server Programming <https://scn.sap.com/docs/DOC-52887>`_, 
*SAP Professional Journal*, pp 1-13 (originally published in January/February 2008)

.. _c09c:

Schmidt and Li (2009c)
----------------------
Improve communication between your C/C++ applications and SAP systems with SAP NetWeaver RFC SDK - 
`Part 3: Advanced Topics <https://scn.sap.com/docs/DOC-52888>`_, 
*SAP Professional Journal*, pp 1-18 (originally published in March 2008)
